package com.lti.vehicle.controller;

	import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.validation.BindingResult;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	import org.springframework.web.servlet.ModelAndView;

import com.lti.vehicle.model.AccountDetails;
import com.lti.vehicle.model.Claim;
import com.lti.vehicle.model.UserDetails;
import com.lti.vehicle.model.VehicleDetails;
import com.lti.vehicle.service.ClaimServiceImpl;
import com.lti.vehicle.service.IAdminService;
import com.lti.vehicle.service.IClaimService;
import com.lti.vehicle.service.IPlanService;
import com.lti.vehicle.service.IVehicleService;
import com.lti.vehicle.service.PaymentServiceDao;
import com.lti.vehicle.service.UserService;

	@Controller
	public class PageController
	{
		
		private UserService userService;
		
		
		private IAdminService iAdminService;

		@Autowired
		public void setiAdminService(IAdminService iAdminService) 
		{
			this.iAdminService = iAdminService;
		}


		@Autowired
		public void setiClaimService(IClaimService iClaimService)
		{
			this.iClaimService = iClaimService;
		}
		@Autowired
		public void setIVehicleService(IVehicleService iVehicleService) 
		{
			IVehicleService = iVehicleService;
		}
		
		@Autowired
		public void setIPlanService(IPlanService iPlanService) 
		{
			IPlanService = iPlanService;
		}
		@Autowired
		public void setPaymentServiceDao(PaymentServiceDao paymentServiceDao) 
		{
			PaymentServiceDao = paymentServiceDao;
		}


		private IClaimService iClaimService;
		private IVehicleService IVehicleService;
		private IPlanService IPlanService;
		private PaymentServiceDao PaymentServiceDao;

		@Autowired
		public void setUserService(UserService ps) 
		{
			this.userService = ps;
		}
	
		
		
		@RequestMapping(value={"/"})
		public ModelAndView goHome() 
		{
			ModelAndView mv=new ModelAndView("index.jsp");
		return mv;
		}
		
	 	
//DispatcherServlet resolves the view using View Resolvers and View
		@RequestMapping(value="/welcome")
		public ModelAndView welcome() 
		{
			ModelAndView mv=new ModelAndView("welcome");
			return mv;
		}
	
	
		@RequestMapping("/login")
		public String showLoginView(Model model)
		{
		model.addAttribute("userDetails", new UserDetails());
		return "login";
		}



@RequestMapping(value="/register")
public String goRegister(Model model) 
{
model.addAttribute("userDetails",new UserDetails());
return "register";
}


		@RequestMapping(value="/register/add" ,method = RequestMethod.POST)
			public String addUser(@ModelAttribute("user") UserDetails u,BindingResult result, Model model) {
		try {
			if (!result.hasErrors()) {			
				if (u.getId() == null || u.getId() == 0) {
						this.userService.addUser(u);
				}  
			 
				return "redirect:/login";
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	
		return "register";
		}
		
		@RequestMapping(value= {"/logout","/vehicles/plans/calculate/logout"})
		public String logout(HttpSession session)
		{
			session.invalidate();
			return "redirect:/";
		}

		
		
		
		
		@RequestMapping(value ="/loginVerification1", method = RequestMethod.POST)
		public String LoginValidation1(@ModelAttribute ("userDetails") @Valid UserDetails u,
				BindingResult result,HttpServletRequest req ,HttpSession session,Model model ) 
		{
			
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			
			if(email.equals("admin@gmail.com")&& password.equals("admin"))
			{
				return "adminprofile";
			}
			else if(userService.verifyUser(email, password))
			{
			
			UserDetails userDetails= userService.getByEmail(email);
		
			session.setAttribute("uDetails", userDetails);
			session.setAttribute("email", userDetails.getEmail());
			System.out.println("Login success");
	
					return "welcome";
		     }
			else
			{
				return "redirect:/login";
			}
		}
			
		@RequestMapping(value="/Accountdetails")
		public String accountdetails(Model model,UserDetails userDetails,HttpSession session ) {
		model.addAttribute("userDetails",new UserDetails());
		model.addAttribute("accountDetails",new AccountDetails());
		return "accountdetails";
		} 

//Admin operations
		
		

		@RequestMapping(value="/listclaims", method=RequestMethod.GET)
		public String listdetails(Model model) {
		try
		{
			List l=iAdminService.claimlist();
			model.addAttribute("listclaims", l);
			System.out.println("inside"+l);
			
		}catch(Throwable t)
		{
			t.printStackTrace();
		}
		return "listclaims";
		}

		
		
//accept
		@RequestMapping("/accept/{claimId}") 
		public String acceptStatus(  @PathVariable("claimId") int claimId, Model model)
		{
	
			List<Claim>c=iAdminService.fetchClaimDetails(claimId);;
		
			this.iAdminService.acceptClaim(claimId);
			List<Claim> claim= this.iAdminService.claimlist();
			model.addAttribute("claim",claim);
			return "redirect:/adminapprove";
		}
		
		
		@RequestMapping("/reject/{claimId}")
		public String rejectStatus(  @PathVariable("claimId") int claimId, Model model)
		{
			List<Claim>c=iAdminService.fetchClaimDetails(claimId);;
			this.iAdminService.acceptClaim(claimId);
			List<Claim> claim= this.iAdminService.claimlist();
			model.addAttribute("claim",claim);
			return "redirect:/admindisapprove";
		}


}
	

