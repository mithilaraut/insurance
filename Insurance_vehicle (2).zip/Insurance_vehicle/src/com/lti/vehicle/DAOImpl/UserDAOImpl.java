package com.lti.vehicle.DAOImpl;

	import java.util.Iterator;
	import java.util.List;

	import org.hibernate.Query;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;

import com.lti.vehicle.dao.UserDao;
import com.lti.vehicle.model.UserDetails;


	@Repository("userDAO")
	 
	public class UserDAOImpl implements UserDao {
		private static final Logger logger = 			
				LoggerFactory.getLogger(UserDAOImpl.class);
		
	 

	 
		Transaction tx;
		@Autowired
		private SessionFactory sessionFactory;
		public void setSessionFactory(SessionFactory sf) 
		{
			this.sessionFactory = sf;
		}
	
		@Override
		public void addUser(UserDetails u) 
		{
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(u);
			tx.commit();
			session.close();
			logger.info("User details saved successfully, User Details="+ u);
		}
		
	
	@Override
	public boolean verifyUser(String email, String password)
{
		Session session = this.sessionFactory.openSession();
		 tx=session.beginTransaction();
		  String query="select email, password from UserDetails u where u.email=:email and u.password=:password";	
          Query q=session.createQuery(query);
          q.setString("email",email);
		  q.setString("password",password);
		 
		  System.out.println(5);
			  List<UserDetails> l=q.list();
			  if(l.size()==0)
			  {
				  System.out.println("thiss inside");
			    return false;
			  }
			  System.out.println("if there is data");
			 tx.commit(); 
		  session.close();
		  return true;
	}

	
	public UserDetails getByEmail(String email) 
	{
		Session session = this.sessionFactory.openSession();
		String query = "from UserDetails u where u.email=:email";
		Query q = session.createQuery(query);
		 q.setString("email", email);
		
		  List<UserDetails> l=q.list();

		if (l.size() == 0) {
			return null;
		}
		UserDetails userDetails = (UserDetails) l.get(0);
		session.close();
		return userDetails;
	}
	}


	
