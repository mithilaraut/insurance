package com.lti.vehicle.DAOImpl;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.lti.vehicle.dao.VehicleDao;
import com.lti.vehicle.model.UserDetails;
import com.lti.vehicle.model.VehicleDetails;


@Transactional
//@Repository
public class VehicleDaoImpl implements VehicleDao {
	private static final Logger logger = 			
			LoggerFactory.getLogger(VehicleDaoImpl.class);

	private SessionFactory sessionFactory;


	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}


	@Override
	public void addVehicle(VehicleDetails v) {
			Session session = this.sessionFactory.openSession();
			Transaction tx= session.beginTransaction();
			session.save(v);
			logger.info("Vehicle Details added successfully, Vehicle Details="+ v);
			tx.commit();
		}


	@Override
	public VehicleDetails getVehicleById(Integer vehicleId) {
		Session session = sessionFactory.openSession();
		
		// if we call get method,Record doesnot exist it will return null
		// if we call load, if the record doesnt exist it will throw exception
		VehicleDetails vehicleDetails = (VehicleDetails)session.get(VehicleDetails.class, vehicleId);
		session.close();
		return vehicleDetails;
	}
	}


	

