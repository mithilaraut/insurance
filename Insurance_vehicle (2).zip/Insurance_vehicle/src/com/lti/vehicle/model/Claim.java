package com.lti.vehicle.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CLAIM")
public class Claim implements Serializable {

/*	@OneToOne(mappedBy="claim",cascade=CascadeType.ALL)
	private UserDetails userDetails;*/
	
	@OneToOne(mappedBy="claim",cascade=CascadeType.ALL)
	private Plans plans;
	
	
/*	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	*/
	
	@OneToOne(mappedBy="tempClaim", cascade = CascadeType.ALL)
	 	private ApplicationInsurance applicationInsurance;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer claimId;
	private String claimDate;
	private String claimReason;
	private String claimStatus;
	
	
     
	/*@Override
	public String toString() {
		return "Claim [userDetails=" + userDetails + ", plans=" + plans + ", applicationInsurance="
				+ applicationInsurance + ", claimId=" + claimId + ", claimDate=" + claimDate + ", claimReason="
				+ claimReason + ", claimStatus=" + claimStatus + "]";
	}*/
	public Plans getPlans() {
		return plans;
	}
	@Override
	public String toString() {
		return "Claim [plans=" + plans + ", applicationInsurance=" + applicationInsurance + ", claimId=" + claimId
				+ ", claimDate=" + claimDate + ", claimReason=" + claimReason + ", claimStatus=" + claimStatus + "]";
	}
	public void setPlans(Plans plans) {
		this.plans = plans;
	}
	public ApplicationInsurance getApplicationInsurance() {
		return applicationInsurance;
	}
	public void setApplicationInsurance(ApplicationInsurance applicationInsurance) {
		this.applicationInsurance = applicationInsurance;
	}
	public Integer getClaimId() {
		return claimId;
	}
	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}
	public String getClaimDate() {
		return claimDate;
	}
	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}
	public String getClaimReason() {
		return claimReason;
	}
	public void setClaimReason(String claimReason) {
		this.claimReason = claimReason;
	}
	public String getClaimStatus() {
		return claimStatus;
	}
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	public Claim() {
		super();

	}
		
}
