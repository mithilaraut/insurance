package com.lti.vehicle.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ApplicationInsurance")
public class ApplicationInsurance {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
		private Integer applicationId;
	

	@OneToOne(cascade=CascadeType.ALL)
	private UserDetails userDetails;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	private VehicleDetails tempVehicle;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Plans tempPlan;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	private Payment tempPayment;

	@OneToOne(cascade=CascadeType.ALL)
	private Claim tempClaim;
	

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	
	
	public Claim getTempClaim() {
		return tempClaim;
	}

	public void setTempClaim(Claim tempClaim) {
		this.tempClaim = tempClaim;
	}


	
	
	public Payment getTempPayment() {
		return tempPayment;
	}

	public void setTempPayment(Payment tempPayment) {
		this.tempPayment = tempPayment;
	}


	
	
	


	public ApplicationInsurance() {
		super();
 
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public VehicleDetails getTempVehicle() {
		return tempVehicle;
	}

	public void setTempVehicle(VehicleDetails tempVehicle) {
		this.tempVehicle = tempVehicle;
	}

	public Plans getTempPlan() {
		return tempPlan;
	}

	public void setTempPlan(Plans tempPlan) {
		this.tempPlan = tempPlan;
	}
	
	
	

}
