package com.lti.vehicle.dao;

import com.lti.vehicle.model.VehicleDetails;

public interface VehicleDao 
{
	 public void addVehicle (VehicleDetails v);
	 VehicleDetails getVehicleById(Integer vehicleId);

}
