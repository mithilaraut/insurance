package com.lti.vehicle.dao;

import com.lti.vehicle.model.Plans;

public interface PlansDao 
{
	
	 public void addPlan (Plans p);

}

