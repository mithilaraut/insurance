package com.lti.vehicle.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lti.vehicle.dao.VehicleDao;
import com.lti.vehicle.model.VehicleDetails;

public class VehicleService implements IVehicleService {
	@Autowired
	VehicleDao vehicleDao;


public void setVehicleDao(VehicleDao vehicleDao) {
	this.vehicleDao = vehicleDao;
}



@Override
	public void addVehicle(VehicleDetails v) {
		// TODO Auto-generated method stub
	this.vehicleDao.addVehicle(v);
	}


@Override
public VehicleDetails getVehicleById(Integer vehicleId) {
	// TODO Auto-generated method stub
return this.vehicleDao.getVehicleById(vehicleId);
}

	
}
