package com.lti.vehicle.service;

import com.lti.vehicle.model.VehicleDetails;

public interface IVehicleService {
	 public void addVehicle (VehicleDetails v);
	 VehicleDetails getVehicleById(Integer vehicleId);

}
