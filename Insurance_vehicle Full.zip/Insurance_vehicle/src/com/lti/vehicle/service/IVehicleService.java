package com.lti.vehicle.service;

import com.lti.vehicle.model.VehicleDetails;

public interface IVehicleService {
	 public void addVehicle (VehicleDetails v);
/*	 public List<VehicleDetails> listVehicleDetails();*/
	 VehicleDetails getVehicleById(Integer vehicleId);

}
