package com.lti.vehicle.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.executable.ValidateOnExecution;





//@Component
@Entity
@Table(name="VEHICLEDETAILS")
public class VehicleDetails implements Serializable {
	
	
	
	
	@OneToOne(cascade=CascadeType.ALL,mappedBy="vehicleDetails")
	private UserDetails userDetails;
	
	
	 public UserDetails getUserDetails() {
		return userDetails;
	}


	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}


	@OneToOne(mappedBy = "tempVehicle", cascade = CascadeType.ALL)
	private ApplicationInsurance applicationInsurance;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer vehicleId;
	 
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "planId")
	private Plans plans;	
	
	@Column
	private String  vehicleType;
	@Column
	private String  brand;
	@Column
	private String model;
	@Column
	//@NotEmpty(message = " License number must be of 13 digits")
	private String license;
	//@NotEmpty(message = " Year must be in 4 digits")
	@Column
	private int purchaseMonth;
	@Column
	private int purchaseYear;
	@Column
	private String regNumber;
	@Column
	private String engineNum;
	@Column
	private String ChasisNum;
	
	
	public VehicleDetails() {
		super();
		}


	public ApplicationInsurance getApplicationInsurance() {
		return applicationInsurance;
	}


	public void setApplicationInsurance(ApplicationInsurance applicationInsurance) {
		this.applicationInsurance = applicationInsurance;
	}


	public Integer getVehicleId() {
		return vehicleId;
	}


	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}


	public Plans getPlans() {
		return plans;
	}


	public void setPlans(Plans plans) {
		this.plans = plans;
	}


	public String getVehicleType() {
		return vehicleType;
	}


	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getLicense() {
		return license;
	}


	public void setLicense(String license) {
		this.license = license;
	}


	public int getPurchaseMonth() {
		return purchaseMonth;
	}


	public void setPurchaseMonth(int purchaseMonth) {
		this.purchaseMonth = purchaseMonth;
	}


	public int getPurchaseYear() {
		return purchaseYear;
	}


	public void setPurchaseYear(int purchaseYear) {
		this.purchaseYear = purchaseYear;
	}


	public String getRegNumber() {
		return regNumber;
	}


	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}


	public String getEngineNum() {
		return engineNum;
	}


	public void setEngineNum(String engineNum) {
		this.engineNum = engineNum;
	}


	public String getChasisNum() {
		return ChasisNum;
	}


	public void setChasisNum(String chasisNum) {
		ChasisNum = chasisNum;
	}


	@Override
	public String toString() {
		return "VehicleDetails [applicationInsurance=" + applicationInsurance + ", vehicleId=" + vehicleId + ", plans="
				+ plans + ", vehicleType=" + vehicleType + ", brand=" + brand + ", model=" + model + ", license="
				+ license + ", purchaseMonth=" + purchaseMonth + ", purchaseYear=" + purchaseYear + ", regNumber="
				+ regNumber + ", engineNum=" + engineNum + ", ChasisNum=" + ChasisNum + "]";
	}


}






