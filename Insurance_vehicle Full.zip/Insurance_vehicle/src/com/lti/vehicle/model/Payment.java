package com.lti.vehicle.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PAYMENT")
public class Payment {

	@OneToOne(mappedBy="payment",cascade=CascadeType.ALL)
	private UserDetails userDetails;
	
	
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	
	
	@OneToOne(cascade=CascadeType.ALL)
	private Claim claim;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer payId;
	private double payAmount;
	
	
	@Override
	public String toString() {
		return "Payment [payId=" + payId + ", payAmount=" + payAmount + "]";
	}


	public Integer getPayId() {
		return payId;
	}


	public void setPayId(Integer payId) {
		this.payId = payId;
	}


	public double getPayAmount() {
		return payAmount;
	}


	public void setPayAmount(double payAmount) {
		this.payAmount = payAmount;
	}


	public Payment() {
		super();
	}
	
	
}
