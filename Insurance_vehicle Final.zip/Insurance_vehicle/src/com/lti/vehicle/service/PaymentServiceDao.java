package com.lti.vehicle.service;

import com.lti.vehicle.model.Payment;

public interface PaymentServiceDao {

		 public void addPayment (Payment p);

	}

